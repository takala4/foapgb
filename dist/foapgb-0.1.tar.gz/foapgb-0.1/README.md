foapgb
====

Overview

## Description

Python package for solving Fujita and Ogawa (1982) model with the accelerated projected gradient method and the balancing method (APGB).

## Requirement



## Install

## Usage

## Demo

## Licence

[MIT](https://github.com/tcnksm/tool/blob/master/LICENCE)

## Reference
[1]User Name, 'Paper Titile' Conference Name pp.xx 20XX

[tcnksm](https://github.com/tcnksm)