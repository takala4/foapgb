if __name__ == '__main__':
    from .core import main
    from .plot import main
    from .test import main
    from .lattice import main
    main()